﻿// ==================== FIREBASE CONFIGURATION ====================
// Your Firebase Web App Configuration
const firebaseConfig = {
    apiKey: "AIzaSyAVmpRPFD_mIl8g8QhNJocypkTAL9X4YRw",
    authDomain: "healthcare-2b685.firebaseapp.com",
    projectId: "healthcare-2b685",
    storageBucket: "healthcare-2b685.firebasestorage.app",
    messagingSenderId: "574392892786",
    appId: "1:574392892786:web:5b656f0636a54db40471eb",
    measurementId: "G-0PYQG3TWLR"
};

// ==================== FASTAPI BACKEND CONFIG ====================
// Backend URL - Change to your FastAPI server URL
// Local development: http://localhost:8000
// Production: https://your-backend-domain.com
const API_BASE = "http://localhost:8000"; // UPDATE THIS IF NEEDED

// ==================== FIREBASE IMPORTS ====================
// Import Firebase SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";

// Firebase Authentication
import {
    getAuth,
    GoogleAuthProvider,
    signInWithPopup,
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

// Firebase Firestore
import {
    getFirestore,
    collection,
    doc,
    setDoc,
    getDocs,
    getDoc,
    addDoc,
    updateDoc,
    deleteDoc,
    query,
    where,
    orderBy,
    limit,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// ==================== INITIALIZE FIREBASE ====================
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const db = getFirestore(app);

// ==================== FASTAPI API FUNCTIONS ====================
// These functions connect to your FastAPI backend
const api = {
    // Test connection to FastAPI backend
    async testConnection() {
        try {
            const response = await fetch(`${API_BASE}/health`);
            return await response.json();
        } catch (error) {
            console.error("❌ FastAPI connection error:", error);
            return { error: "Cannot connect to backend", status: "offline" };
        }
    }, 
    // [ADD THIS FUNCTION]
    // Get Configuration (Maps Key)
    async getMapsConfig() {
        try {
            const response = await fetch(`${API_BASE}/api/config`);
            if (!response.ok) throw new Error("Failed to fetch config");
            return await response.json();
        } catch (error) {
            console.error("❌ Config error:", error);
            return null;
        }
    },   // Download PDF Report
    // [REPLACE THE OLD downloadPDF FUNCTION WITH THIS]
    async downloadPDF(uid) {
        try {
            console.log(`📥 Downloading PDF for: ${uid}`);
            showToast("Generating PDF... This may take a few seconds.", "info");

            const response = await fetch(`${API_BASE}/api/download-report/${uid}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/pdf'
                }
            });

            if (!response.ok) throw new Error("PDF generation failed");

            // Convert response to a blob (binary file)
            const blob = await response.blob();
            
            // Create a temporary link to trigger download
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `HealthReport_${uid}.pdf`; // The filename
            document.body.appendChild(a); // Append to body (required for Firefox)
            a.click();
            
            // Cleanup
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            
            showToast("Report Downloaded!", "success");
            return { status: "success" };

        } catch (error) {
            console.error("❌ PDF Download error:", error);
            showToast("Failed to download PDF", "error");
            return { error: error.message };
        }
    },


    // Health Analysis - calls /api/generate-conclusion
    async generateAnalysis(uid) {
        try {
            console.log(`📊 Generating AI analysis for user: ${uid}`);
            
            const response = await fetch(`${API_BASE}/api/generate-conclusion`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    uid: uid,
                    timestamp: new Date().toISOString()
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log("✅ AI analysis generated successfully");
            return data;
            
        } catch (error) {
            console.error("❌ AI Analysis API error:", error);
            return {
                error: error.message,
                result: "⚠️ AI analysis service is temporarily unavailable. Please try again later."
            };
        }
    },

    // Chat with AI Assistant - calls /api/chat
    async chatWithAI(uid, message) {
        try {
            console.log(`💬 Chat request from ${uid}: ${message.substring(0, 50)}...`);
            
            const response = await fetch(`${API_BASE}/api/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    uid: uid,
                    message: message,
                    timestamp: new Date().toISOString()
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log("✅ Chat response received");
            return data;
            
        } catch (error) {
            console.error("❌ Chat API error:", error);
            return {
                error: error.message,
                reply: "⚠️ I'm having trouble connecting right now. Please try again in a moment."
            };
        }
    },

    // Analyze Medical Image - calls /api/analyze-image
    async analyzeImage(uid, file) {
    try {
        console.log(`🖼️ Image analysis for ${uid}, file: ${file.name}`);
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('uid', uid);
        
        const response = await fetch(`${API_BASE}/api/analyze-image`, {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log("✅ Image analysis completed");
        return data;
        
    } catch (error) {
        console.error("❌ Image analysis API error:", error);
        return {
            error: error.message,
            result: "⚠️ Image analysis service is temporarily unavailable. Please try again later."
        };
    }
},
   async saveImageAnalysis(uid, analysisData) {
        try {
            console.log(`💾 Saving image analysis for user: ${uid}`);
            
            const response = await fetch(`${API_BASE}/api/save-analysis`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    uid: uid,
                    type: 'image_analysis',
                    data: analysisData,
                    timestamp: new Date().toISOString()
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log("✅ Image analysis saved successfully");
            return data;
            
        } catch (error) {
            console.error("❌ Save image analysis error:", error);
            return {
                error: error.message,
                result: "⚠️ Failed to save analysis. Please try again."
            };
        }
    },

    // SAVE HEALTH ANALYSIS TO DATABASE
    async saveHealthAnalysis(uid, analysisData) {
        try {
            console.log(`💾 Saving health analysis for user: ${uid}`);
            
            const response = await fetch(`${API_BASE}/api/save-analysis`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    uid: uid,
                    type: 'health_analysis',
                    data: analysisData,
                    timestamp: new Date().toISOString()
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log("✅ Health analysis saved successfully");
            return data;
            
        } catch (error) {
            console.error("❌ Save health analysis error:", error);
            return {
                error: error.message,
                result: "⚠️ Failed to save analysis. Please try again."
            };
        }
    },

    // GET SAVED ANALYSES
    async getSavedAnalyses(uid) {
        try {
            console.log(`📚 Getting saved analyses for user: ${uid}`);
            
            const response = await fetch(`${API_BASE}/api/get-analyses/${uid}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log("✅ Retrieved saved analyses");
            return data;
            
        } catch (error) {
            console.error("❌ Get analyses error:", error);
            return {
                error: error.message,
                analyses: []
            };
        }
    },

    // DELETE SAVED ANALYSIS
    async deleteAnalysis(uid, analysisId) {
        try {
            console.log(`🗑️ Deleting analysis: ${analysisId} for user: ${uid}`);
            
            const response = await fetch(`${API_BASE}/api/delete-analysis`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    uid: uid,
                    analysis_id: analysisId,
                    timestamp: new Date().toISOString()
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log("✅ Analysis deleted");
            return data;
            
        } catch (error) {
            console.error("❌ Delete analysis error:", error);
            return {
                error: error.message,
                result: "⚠️ Failed to delete analysis."
            };
        }
    },
    // Delete Record via FastAPI (optional - can also use Firestore directly)
    async deleteRecord(uid, collectionName, docId) {
        try {
            console.log(`🗑️ Deleting ${collectionName}/${docId} for ${uid}`);
            
            const response = await fetch(`${API_BASE}/api/delete-record`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    uid: uid,
                    collection: collectionName,
                    id: docId
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log("✅ Record deleted via API");
            return data;
            
        } catch (error) {
            console.error("❌ Delete API error:", error);
            return {
                error: error.message,
                status: "error",
                message: "Failed to delete record via API"
            };
        }
    },

    // Get Health Summary - calls /api/health-summary/{uid}
    async getHealthSummary(uid) {
        try {
            const response = await fetch(`${API_BASE}/api/health-summary/${uid}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
            
        } catch (error) {
            console.error("❌ Health summary API error:", error);
            return {
                error: error.message,
                summary: "⚠️ Could not fetch health summary."
            };
        }
    }
};

// ==================== UTILITY FUNCTIONS ====================
// Helper function to show toast notifications
function showToast(message, type = 'info') {
    console.log(`📢 ${type.toUpperCase()}: ${message}`);
    
    // Create toast element if container exists
    if (document.getElementById('toastContainer')) {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <span>${message}</span>
            <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }
}

// Helper function to get readable type names
function getTypeName(type) {
    const names = {
        'bp': 'Blood Pressure',
        'hr': 'Heart Rate',
        'bs': 'Blood Sugar',
        'wt': 'Weight'
    };
    return names[type] || type;
}

// Helper function to get units
function getUnit(type) {
    const units = {
        'bp': 'mmHg',
        'hr': 'bpm',
        'bs': 'mg/dL',
        'wt': 'kg'
    };
    return units[type] || '';
}

// ==================== EXPORT EVERYTHING ====================
// Export Firebase functions
export {
    // Firebase core
    auth,
    db,
    provider,
    
    // Auth functions
    signInWithPopup,
    signInWithEmailAndPassword,
    createUserWithEmailAndPassword,
    onAuthStateChanged,
    signOut,
    
    // Firestore functions
    collection,
    doc,
    setDoc,
    getDocs,
    getDoc,
    addDoc,
    updateDoc,
    deleteDoc,
    query,
    where,
    orderBy,
    limit,
    serverTimestamp,
    
    // API functions
    api,
    
    // Utility functions
    showToast,
    getTypeName,
    getUnit
};

// ==================== INITIALIZATION ====================
// Log initialization
console.log("✅ Firebase SDK initialized successfully");
console.log(`🌐 Backend API Base: ${API_BASE}`);
console.log(`🔥 Firebase Project: ${firebaseConfig.projectId}`);

// Test backend connection on load
setTimeout(async () => {
    try {
        const test = await api.testConnection();
        console.log("🔗 Backend connection test:", test);
    } catch (error) {
        console.warn("⚠️ Backend connection test failed - starting without backend");
    }
}, 1000);