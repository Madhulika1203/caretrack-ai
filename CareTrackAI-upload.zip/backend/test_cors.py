import requests

# Test backend
print("Testing backend connection...")
try:
    response = requests.get("http://localhost:8000/health")
    print(f"Status: {response.status_code}")
    print(f"Headers: {dict(response.headers)}")
    print(f"Response: {response.text}")
except Exception as e:
    print(f"Error: {e}")

# Test CORS headers
print("\n\nTesting CORS headers...")
try:
    response = requests.options("http://localhost:8000/health")
    print(f"CORS Headers: {dict(response.headers)}")
except Exception as e:
    print(f"Error: {e}")
