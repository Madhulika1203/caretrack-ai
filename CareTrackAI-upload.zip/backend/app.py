# --- STANDARD IMPORTS ---
import os
import json
import tempfile
import io  # <--- THIS WAS MISSING
import re
from datetime import datetime
# [UPDATE YOUR IMPORTS]
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Flowable
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT
# --- FASTAPI IMPORTS ---
from fastapi import FastAPI, HTTPException, Request, UploadFile, File, Form
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

# --- FIREBASE & GEMINI IMPORTS ---
import firebase_admin
from firebase_admin import credentials, firestore
from google import genai
from google.genai import types

# --- REPORTLAB (PDF) IMPORTS ---
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.graphics.shapes import Drawing, String
from reportlab.graphics import renderPDF

# --- Configuration ---
BASE_DIR = os.path.abspath(os.path.dirname(__file__))   # project/backend
PROJECT_DIR = os.path.abspath(os.path.join(BASE_DIR, ".."))
FRONTEND_DIR = os.path.join(PROJECT_DIR, "frontend")
SDK_PATH = os.path.join(BASE_DIR, "sdk.js")
ADMIN_SDK_PATH = os.path.join(BASE_DIR, "admindsk.json")

# --- Firebase Admin Init ---
if not firebase_admin._apps:
    if os.path.exists(ADMIN_SDK_PATH):
        cred = credentials.Certificate(ADMIN_SDK_PATH)
        firebase_admin.initialize_app(cred)
        print("✅ Firebase Admin Initialized")
    else:
        print(f"⚠️ Warning: Admin SDK not found at {ADMIN_SDK_PATH}")

db = firestore.client()

# --- Gemini AI Init ---
# Use environment variable or hardcode your key
# ... existing config ...
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyBq5CxDUHJE_ehSvuQL-GPhrZiakKE2ui0")

# [ADD THIS LINE]
GOOGLE_MAPS_API_KEY = os.environ.get("GOOGLE_MAPS_API_KEY", "AIzaSyBq5CxDUHJE_ehSvuQL-GPhrZiakKE2ui0")
if GEMINI_API_KEY == "YOUR_GEMINI_API_KEY_HERE":
    print("⚠️ Warning: Using default Gemini API key. Replace with your own.")
    
client = genai.Client(api_key=GEMINI_API_KEY)

app = FastAPI(title="HealthTrack Backend API")

# CORS Configuration - Allow frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow all origins for easier testing
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# --- Helper Functions ---
def get_user_health_context(uid: str):
    """Fetch user's health data and diagnoses for AI context"""
    try:
        # Get health data
        health_ref = db.collection("healthData").where("uid", "==", uid).order_by("createdAt", direction=firestore.Query.DESCENDING).limit(20)
        health_docs = health_ref.stream()
        health_data = []
        for doc in health_docs:
            data = doc.to_dict()
            data['id'] = doc.id
            health_data.append(data)
        
        # Get diagnoses
        diag_ref = db.collection("diagnoses").where("uid", "==", uid).order_by("createdAt", direction=firestore.Query.DESCENDING).limit(10)
        diag_docs = diag_ref.stream()
        diag_data = []
        for doc in diag_docs:
            data = doc.to_dict()
            data['id'] = doc.id
            diag_data.append(data)
        
        # Get user profile
        user_profile = {}
        try:
            user_doc = db.collection("users").document(uid).get()
            if user_doc.exists:
                user_profile = user_doc.to_dict()
        except:
            pass
        
        return {
            "health_data": health_data,
            "diagnoses": diag_data,
            "profile": user_profile
        }
    except Exception as e:
        print(f"Error fetching user context: {e}")
        return {"health_data": [], "diagnoses": [], "profile": {}}

def format_context_for_ai(context: dict) -> str:
    """Format health context for AI prompt"""
    health_data = context["health_data"]
    diagnoses = context["diagnoses"]
    profile = context["profile"]
    
    context_str = "=== PATIENT HEALTH CONTEXT ===\n\n"
    
    # Profile info
    if profile:
        context_str += f"👤 Patient Profile:\n"
        context_str += f"- Name: {profile.get('displayName', 'Not provided')}\n"
        context_str += f"- Age: {profile.get('age', 'Not provided')}\n"
        context_str += f"- Gender: {profile.get('gender', 'Not provided')}\n"
        context_str += f"- Blood Type: {profile.get('bloodType', 'Not provided')}\n"
        context_str += f"- Height: {profile.get('height', 'Not provided')} cm\n"
        context_str += f"- Weight: {profile.get('weight', 'Not provided')} kg\n\n"
    
    # Health data grouped by type
    bp_data = [h for h in health_data if h.get('type') == 'bp']
    hr_data = [h for h in health_data if h.get('type') == 'hr']
    bs_data = [h for h in health_data if h.get('type') == 'bs']
    wt_data = [h for h in health_data if h.get('type') == 'wt']
    
    if bp_data:
        context_str += f"🩺 Blood Pressure ({len(bp_data)} readings):\n"
        for h in bp_data[:5]:  # Show latest 5
            context_str += f"  • {h.get('value', 'N/A')} mmHg ({h.get('createdAt', 'No date')})\n"
        context_str += "\n"
    
    if hr_data:
        context_str += f"💓 Heart Rate ({len(hr_data)} readings):\n"
        for h in hr_data[:5]:
            context_str += f"  • {h.get('value', 'N/A')} bpm ({h.get('createdAt', 'No date')})\n"
        context_str += "\n"
    
    if bs_data:
        context_str += f"🩸 Blood Sugar ({len(bs_data)} readings):\n"
        for h in bs_data[:5]:
            context_str += f"  • {h.get('value', 'N/A')} mg/dL ({h.get('createdAt', 'No date')})\n"
        context_str += "\n"
    
    if wt_data:
        context_str += f"⚖️ Weight ({len(wt_data)} readings):\n"
        for h in wt_data[:5]:
            context_str += f"  • {h.get('value', 'N/A')} kg ({h.get('createdAt', 'No date')})\n"
        context_str += "\n"
    
    # Diagnoses
    if diagnoses:
        context_str += "🏥 Medical Diagnoses:\n"
        for d in diagnoses:
            title = d.get('title', 'Untitled')
            desc = d.get('description', d.get('notes', ''))
            date = d.get('date', d.get('createdAt', 'No date'))
            context_str += f"  • {title}: {desc} ({date})\n"
        context_str += "\n"
    
    return context_str

# --- API Endpoints ---

@app.get("/")
async def root():
    """Root endpoint - Welcome message"""
    return {
        "message": "🚀 HealthTrack Backend API is running!",
        "version": "1.0.0",
        "endpoints": {
            "health": "GET /health - Service health check",
            "chat": "POST /api/chat - AI health assistant chat",
            "analysis": "POST /api/generate-conclusion - Generate health analysis",
            "image_analysis": "POST /api/analyze-image - Analyze medical images",
            "delete": "POST /api/delete-record - Delete health records",
            "save_analysis": "POST /api/save-analysis - Save analysis result",
            "get_analyses": "GET /api/get-analyses/{uid} - Get saved analyses"
        },
        "docs": "Visit /docs for API documentation"
    }
@app.get("/api/config")
async def get_config():
    """
    Serve public configuration keys securely
    """
    return {
        "maps_api_key": GOOGLE_MAPS_API_KEY
    }
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "firebase": "initialized" if firebase_admin._apps else "not_initialized",
        "gemini": "available" if GEMINI_API_KEY and GEMINI_API_KEY != "YOUR_GEMINI_API_KEY_HERE" else "not_configured",
        "timestamp": firestore.SERVER_TIMESTAMP
    }

# --- Helper to Get Chat History (ADD THIS) ---
# --- Helper to Get Chat History (Context-Aware) ---
def get_chat_history(uid: str, limit: int = 10):
    try:
        # Note: If you see "The query requires an index" error, click the link in your terminal/console.
        history_ref = db.collection("chatLogs")\
                        .where("uid", "==", uid)\
                        .order_by("timestamp", direction=firestore.Query.DESCENDING)\
                        .limit(limit)
        docs = history_ref.stream()
        
        history = []
        for doc in docs:
            data = doc.to_dict()
            u_msg = str(data.get("user_message", ""))
            a_msg = str(data.get("ai_response", ""))
            
            if u_msg:
                history.append({"role": "user", "parts": [{"text": u_msg}]})
            if a_msg:
                history.append({"role": "model", "parts": [{"text": a_msg}]})
        
        return history[::-1] # Reverse to get oldest -> newest
    except Exception as e:
        print(f"⚠️ Warning: Could not fetch chat history: {e}")
        return []
@app.post("/api/chat")
async def chat_endpoint(request: Request):
    """
    AI Health Assistant Chat with Context & Map Trigger
    """
    try:
        body = await request.json()
        uid = body.get("uid")
        user_message = body.get("message")
        
        if not uid or not user_message:
            raise HTTPException(status_code=400, detail="Missing data")
        
        # 1. Get Contexts
        context = get_user_health_context(uid)
        context_str = format_context_for_ai(context)
        chat_history = get_chat_history(uid)
        
        # 2. System Prompt
        system_instruction = f"""You are "HealthTrack AI", a medical assistant.
        Patient Context: {context_str}
        
        If user has a symptom needing a specialist, append: ||MAP_SEARCH: <Specialist Type>||
        """
        
        # 3. Generate Response
        ai_reply = ""
        
        try:
            # Construct message list manually for robustness
            messages = [{"role": "user", "parts": [{"text": system_instruction}]}] 
            
            if chat_history:
                messages.extend(chat_history)
                
            messages.append({"role": "user", "parts": [{"text": user_message}]})
            
            # Use standard generate_content (stateless call but with full history passed)
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=messages
            )
            
            if hasattr(response, 'text') and response.text:
                ai_reply = str(response.text)
            else:
                ai_reply = "I'm thinking..."

        except Exception as api_err:
            print(f"API Error: {api_err}")
            ai_reply = "I'm having trouble connecting. Please try again."

        # 4. Save to Firestore
        try:
            db.collection("chatLogs").add({
                "uid": uid,
                "user_message": user_message,
                "ai_response": ai_reply,
                "timestamp": firestore.SERVER_TIMESTAMP
            })
        except Exception as db_err:
            print(f"DB Save Error: {db_err}")

        return {"reply": ai_reply}

    except Exception as e:
        print(f"❌ Chat Critical Error: {e}")
        return JSONResponse(status_code=500, content={"error": str(e)})
@app.post("/api/generate-conclusion")
async def generate_conclusion(request: Request):
    """
    Generate AI Health Analysis Report
    """
    try:
        body = await request.json()
        uid = body.get("uid")
        
        print(f"📊 Health analysis requested by {uid}")
        
        if not uid:
            raise HTTPException(status_code=400, detail="Missing uid")
        
        # Get user context
        context = get_user_health_context(uid)
        context_str = format_context_for_ai(context)
        
        # Create analysis prompt
        prompt = f""" Analyze the following patient health data and provide a comprehensive AI-generated health report.

Patient Data:
{context_str}

🧾 Output Rules
If patient data is provided, respond only in the format below.
Must be max 200 words, no markdown, and no headings with markdown (#, ##, etc.).
Must include a highlighted section predicting possible disease/health risk.
Must use emojis.

📌 Required Format (Use plain text with emojis)
🩺 Health Analysis Report
📈 Overall Health Status: [Excellent/Good/Fair/Poor]

🔍 Key Findings
Blood Pressure Analysis
Heart Rate Analysis
Blood Sugar Analysis
Weight/BMI Analysis

✨ Health Risk Prediction (highlight this section)
[Predicted conditions or possible risks]

🎯 Risk Assessment
Immediate Risks
Long-term Risks
Areas Needing Attention

💡 Recommendations
Lifestyle Advice
Monitoring Suggestions
When to Seek Medical Help

📊 Next Steps
Short-term Actions
Long-term Goals
(Include a reminder this is AI guidance only) """
        
        # Call Gemini AI
        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=[
                types.Content(role="user", parts=[types.Part.from_text(text=prompt)])
            ],
            config=types.GenerateContentConfig(
                temperature=0.3,
                max_output_tokens=1500
            )
        )
        
        # Save to Firestore
        conclusion_data = {
            "uid": uid,
            "text": response.text,
            "type": "ai_analysis",
            "createdAt": firestore.SERVER_TIMESTAMP
        }
        
        try:
            doc_ref = db.collection("healthConclusions").add(conclusion_data)
            print(f"✅ Analysis saved to Firestore for {uid}")
        except Exception as e:
            print(f"⚠️ Could not save analysis to Firestore: {e}")
        
        return {"result": response.text}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Analysis error: {e}")
        return JSONResponse(
            status_code=500,
            content={"error": "Analysis service temporarily unavailable. Please try again."}
        )

@app.post("/api/analyze-image")
async def analyze_image(uid: str = Form(...), file: UploadFile = File(...)):
    """
    Analyze Medical Images
    """
    try:
        print(f"🖼️ Image analysis requested by {uid}, file: {file.filename}")
        
        # Validate file type
        allowed_types = ["image/jpeg", "image/png", "image/jpg", "image/webp", "image/gif", "image/bmp", "application/pdf"]
        if file.content_type not in allowed_types:
            raise HTTPException(status_code=400, detail="File type not supported. Please upload JPG, PNG, WEBP, or PDF.")
        
        # Read file content
        content = await file.read()
        
        # Prepare Gemini request with image/pdf
        prompt = """Analyze this medical image and provide a detailed analysis in PLAIN TEXT ONLY - NO MARKDOWN.

MEDICAL IMAGE ANALYSIS REPORT and make sure write everything in detailed along with conclusion and make sure to not write any irrelevent information

1. Image Type: What type of medical image is this?
2. Visible Structures: What anatomical structures are visible?
3. Findings: List all observable findings
4. Potential Concerns: Highlight any concerning findings
5. Recommendations: Provide medical recommendations
6. Urgency Level: Low/Medium/High based on findings

If this is not a medical image or if quality is poor, state that clearly.

Use only plain text. No asterisks, no markdown symbols. Use simple colons and line breaks.And write detailed analysis and everything from it if its tooo detailed """
        
        try:
            image_part = types.Part.from_bytes(data=content, mime_type=file.content_type)
            
            response = client.models.generate_content(
                model="gemini-2.0-flash",
                contents=[types.Content(role="user", parts=[image_part, types.Part.from_text(text=prompt)])],
                config=types.GenerateContentConfig(temperature=0.3, max_output_tokens=15000)
            )
            
            if not response.text:
                raise ValueError("Gemini returned empty response")
            
            analysis_result = response.text
            import re
            analysis_result = re.sub(r'\*\*|\*|`|#|\[|\]|\(|\)|_{2,}', '', analysis_result)
            
            image_analysis_data = {
                "uid": uid,
                "filename": file.filename,
                "content_type": file.content_type,
                "analysis": analysis_result,
                "createdAt": firestore.SERVER_TIMESTAMP
            }
            
            try:
                db.collection("imageAnalyses").add(image_analysis_data)
                print(f"✅ Image analysis saved for {uid}")
            except Exception as e:
                print(f"⚠️ Could not save image analysis to Firestore: {e}")
            
            return {"result": analysis_result}
            
        except Exception as gemini_error:
            print(f"❌ Gemini error: {gemini_error}")
            return {
                "result": f"Image analysis completed for {file.filename}.\n\n📄 **Note**: Detailed AI analysis is temporarily unavailable.\n\n💡 **Manual Review**: Please consult your healthcare provider.",
                "filename": file.filename,
                "size": len(content),
                "type": file.content_type
            }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Image analysis error: {e}")
        return JSONResponse(status_code=500, content={"error": f"Image analysis failed: {str(e)}"})

@app.get("/api/get-analyses/{uid}")
async def get_analyses(uid: str, limit: int = 20):
    try:
        print(f"📚 Get analyses request for {uid}")
        analyses_ref = db.collection("analyses").where("uid", "==", uid).limit(limit)
        analyses_docs = analyses_ref.stream()
        analyses = []
        for doc in analyses_docs:
            data = doc.to_dict()
            data["id"] = doc.id
            if hasattr(data.get("createdAt"), "isoformat"):
                data["createdAt"] = data["createdAt"].isoformat()
            analyses.append(data)
        return {"uid": uid, "analyses": analyses, "count": len(analyses), "timestamp": datetime.now().isoformat()}
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": "Could not fetch analyses", "analyses": []})

@app.post("/api/delete-analysis")
async def delete_analysis(request: Request):
    try:
        body = await request.json()
        uid, analysis_id = body.get("uid"), body.get("analysis_id")
        if not uid or not analysis_id: raise HTTPException(status_code=400, detail="Missing uid or analysis_id")
        analysis_ref = db.collection("analyses").document(analysis_id)
        if not analysis_ref.get().exists: raise HTTPException(status_code=404, detail="Analysis not found")
        analysis_ref.delete()
        return {"status": "success", "message": "Analysis deleted successfully", "analysis_id": analysis_id}
    except Exception as e: return JSONResponse(status_code=500, content={"error": f"Delete failed: {str(e)}"})

@app.post("/api/delete-record")
async def delete_record(request: Request):
    try:
        body = await request.json()
        uid, collection_name, doc_id = body.get("uid"), body.get("collection"), body.get("id")
        if not uid or not collection_name or not doc_id: raise HTTPException(status_code=400, detail="Missing data")
        doc_ref = db.collection(collection_name).document(doc_id)
        if not doc_ref.get().exists: raise HTTPException(status_code=404, detail="Document not found")
        doc_ref.delete()
        return {"status": "success", "message": "Record deleted successfully"}
    except Exception as e: return JSONResponse(status_code=500, content={"error": f"Delete failed: {str(e)}"})

@app.get("/api/health-summary/{uid}")
async def get_health_summary(uid: str):
    try:
        print(f"📋 Health summary requested for {uid}")
        latest_data = {}
        metrics = ['bp', 'hr', 'bs', 'wt']
        for metric in metrics:
            query = db.collection("healthData").where("uid", "==", uid).where("type", "==", metric).order_by("createdAt", direction=firestore.Query.DESCENDING).limit(1)
            docs = query.stream()
            for doc in docs:
                latest_data[metric] = {"value": doc.to_dict().get('value'), "timestamp": doc.to_dict().get('createdAt')}
        return {"uid": uid, "latest_readings": latest_data}
    except Exception as e: return JSONResponse(status_code=500, content={"error": "Could not fetch health summary"})

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc): return JSONResponse(status_code=exc.status_code, content={"error": exc.detail})
# [ADD THESE IMPORTS IF MISSING]
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Flowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
import io
import re
from datetime import datetime

# ... existing code ...

@app.get("/api/download-report/{uid}")
async def download_report_endpoint(uid: str):
    """
    Generates a Professional Medical PDF Report with 'Suggest to Doctor' and optimized spacing.
    """
    try:
        print(f"📄 PDF Report requested for {uid}")
        
        # 1. Fetch User Data
        context = get_user_health_context(uid)
        profile = context.get("profile", {})
        
        # Extract Profile Details
        p_name = profile.get("displayName", "Not Recorded")
        p_age = profile.get("age", "N/A")
        p_gender = profile.get("gender", "N/A")
        
        context_str = format_context_for_ai(context)
        
        # 2. Get Professional Content from Gemini
        prompt = f"""
        Act as a Senior Medical Consultant. Write a formal Health Status Report.
        
        STRICT FORMATTING RULES:
        1. NO markdown symbols (no **, ##, -). Use plain text.
        2. Use Title Case for headings (e.g., "Clinical Analysis" not "CLINICAL ANALYSIS").
        3. Use bullet points (•) for lists.
        4. Structure the response exactly into these 5 parts:
        
           SECTION: Executive Summary
           [Concise overview of patient status]
           
           SECTION: Vitals & Clinical Analysis
           [Analysis of available vitals]
           
           SECTION: Diagnostic Assessment
           [Assessment of conditions]
           
           SECTION: Medical Recommendations
           [Actionable steps]
           
           SECTION: Suggested Questions for Doctor
           [3-4 specific, high-value questions the patient should ask their doctor]
        
        Patient Data:
        {context_str}
        """
        
        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=[types.Content(role="user", parts=[types.Part.from_text(text=prompt)])]
        )
        raw_text = response.text if response.text else "Report generation failed."

        # 3. PDF Generation Setup
        buffer = io.BytesIO()
        # Reduced margins (40 instead of 72) to use more space
        doc = SimpleDocTemplate(
            buffer, 
            pagesize=letter,
            rightMargin=40, leftMargin=40, 
            topMargin=40, bottomMargin=40
        )
        
        styles = getSampleStyleSheet()
        
        # --- Custom Professional Styles ---
        style_title = ParagraphStyle(
            'ReportTitle', 
            parent=styles['Heading1'], 
            fontSize=22, 
            textColor=colors.HexColor('#1e293b'), # Dark Slate
            alignment=TA_CENTER,
            spaceAfter=20,
            fontName='Helvetica-Bold'
        )
        
        style_header = ParagraphStyle(
            'SectionHeader',
            parent=styles['Heading2'],
            fontSize=13,
            textColor=colors.HexColor('#0f172a'), # Very Dark Blue/Black
            spaceBefore=15,
            spaceAfter=8,
            alignment=TA_LEFT,
            fontName='Helvetica-Bold'
        )
        
        style_body = ParagraphStyle(
            'ProfessionalBody',
            parent=styles['Normal'],
            fontSize=10, # Smaller, professional font
            leading=14,  # Tight but readable leading
            textColor=colors.HexColor('#334155'),
            alignment=TA_JUSTIFY, # Clean edges
            fontName='Helvetica'
        )
        
        style_meta = ParagraphStyle(
            'MetaInfo',
            parent=styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#64748b'),
            alignment=TA_CENTER
        )

        # --- Custom Stamp Flowable ---
        class EndStamp(Flowable):
            def wrap(self, availWidth, availHeight):
                return (availWidth, 100)

            def draw(self):
                canvas = self.canv
                # Position near bottom right
                x = 450
                y = 10
                
                canvas.saveState()
                canvas.translate(x, y)
                canvas.rotate(15)
                
                # Draw Box
                canvas.setStrokeColor(colors.HexColor('#e2e8f0')) 
                canvas.setLineWidth(2)
                canvas.roundRect(-60, -25, 120, 50, 8, stroke=1, fill=0)
                
                # Draw Text
                canvas.setFillColor(colors.HexColor('#94a3b8')) 
                canvas.setFont("Helvetica-Bold", 12)
                canvas.drawCentredString(0, 5, "CARETRACK AI")
                
                canvas.setFont("Helvetica", 7)
                canvas.drawCentredString(0, -10, "VERIFIED REPORT")
                
                canvas.restoreState()

        # --- Build Story ---
        story = []

        # 1. Title
        story.append(Paragraph("Medical Health Report", style_title))
        
        # 2. Header Info
        header_text = f"<b>PATIENT:</b> {p_name}  |  <b>AGE:</b> {p_age}  |  <b>GENDER:</b> {p_gender}  |  <b>DATE:</b> {datetime.now().strftime('%b %d, %Y')}"
        story.append(Paragraph(header_text, style_meta))
        story.append(Spacer(1, 8))
        story.append(Paragraph("_" * 90, style_meta)) 
        story.append(Spacer(1, 20))

        # 3. Process Content
        sections = raw_text.split("SECTION:")
        
        for section in sections:
            if not section.strip(): continue
            
            parts = section.strip().split('\n', 1)
            title = parts[0].strip() # Keep Title Case from AI
            content = parts[1].strip() if len(parts) > 1 else ""
            
            # Clean Markdown
            content = re.sub(r'\*\*|\*|#', '', content)
            
            # Add Header
            story.append(Paragraph(title, style_header))
            
            # Add Body
            for line in content.split('\n'):
                if line.strip():
                    # Check if it's a bullet point
                    if line.strip().startswith('•') or line.strip().startswith('-'):
                        # Indent bullet points slightly if needed, or just let them flow
                        story.append(Paragraph(line.strip(), style_body))
                    else:
                        story.append(Paragraph(line.strip(), style_body))
                    story.append(Spacer(1, 3))
            
            story.append(Spacer(1, 10))

        # 4. Disclaimer Footer
        story.append(Spacer(1, 25))
        disclaimer = "<i>Disclaimer: This report is generated by AI technology. It is intended for informational purposes only and does not constitute a medical diagnosis. Please consult a qualified healthcare provider for clinical advice.</i>"
        story.append(Paragraph(disclaimer, ParagraphStyle('Disc', parent=styles['Normal'], fontSize=7, textColor=colors.gray, alignment=TA_CENTER)))
        
        # 5. Stamp
        story.append(EndStamp())

        doc.build(story)
        buffer.seek(0)

        return StreamingResponse(
            buffer,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=CareTrack_Report_{uid}.pdf"}
        )

    except Exception as e:
        print(f"❌ PDF Error: {e}")
        return JSONResponse(status_code=500, content={"error": str(e)})
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)